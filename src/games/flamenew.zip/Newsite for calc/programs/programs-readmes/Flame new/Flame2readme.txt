Raging Flame 2
Original concept- Jeff Verkoeyen
Name- Brent Ammann
Graphics- Jeff Verkoeyen
Plot Editing- Brooks Butler
Date made- February, 2002
Features-
	This is the new, updated version of Raging Flame, check out the site for more news about it's development.

FAQ-
Before you ask any questions, make sure that you run setup before running the main program (rgngflme) then make sure that you have enough space on your calculator for the entire game to be in the RAM at the same time.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more