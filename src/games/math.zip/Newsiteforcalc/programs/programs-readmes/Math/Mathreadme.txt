Miscelaneous Math Programs
Original concept- Jeff Verkoeyen
Date made- January, 2001
Features-
	The Factor program can be used in Chapter 10 for Algebra,
all you need to do is type in the A,B, and C variables, and then
it will tell you the factors for it.
	Math 1&2, both have a bunch of different useful conversion programs and plain math programs also.
	Make sure that you have STEMLEAF on your calculator when running the first Math program because it uses that particular program.
	The linearEq and Slope programs are excellent for use in 9th grade Algebra classes, for about the 2nd semester's worth of classes.

Programs included-
	Factor
	Math 1&2
	Linear Equations
	Stem-Leaf
	Quadratic Equations
	Slope

FAQ-
The math programs come up with errors sometimes like ERROR:LABEL....?
	If you see any errors like these, in any of my programs, go to my site and click the submit errors link and then type in where it happened that the error came up, and what you did to make the error happen, if you know.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more