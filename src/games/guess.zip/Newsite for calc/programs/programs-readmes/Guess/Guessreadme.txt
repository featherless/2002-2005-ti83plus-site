Guess
Original concept- Jeff Verkoeyen
Date made(1st)- March, 2001
Date remade(2nd)- January, 2002
Additional features after remake-
	multiple levels of play
	records high scores
	2-player compatible (still a few tiny glitches to fix, but works fine)
	fast game play
	NO WAY mode (picks a number between 1-1000000, but every time you press enter with your new guess, it changes the actual number)
	Custom mode to challenge yourself

To play Guess, just ungroup the Guess group, run program Guess, and then run setup (4 on the main menu) and that will create your high score table.  You only need to run setup once, but you can reset your high scores by running it again.
To play 2-player Guess, send the Guess group to a friend's calculator, and then make them ungroup it, then first player needs to run prgmGUESS, while second player runs prgmGUESS2P.  Player one then clicks 2 Player (2 in the main menu) and types in the limit for the game.  Once both calculators say- Please link the calculators, then you both need to press enter at the exact same time for it to work properly, then, at the bottom of player 2's screen, it should say the same limit player 1's screen says.

FAQ-
When I run setup, it comes up with an error saying "Archived"...what do I do?
	If you see this error, all you need to do is make sure that the list HIGH is unarchived.

While playing the game, I click my difficulty level, and then it says "Archived"...
	Again, look at the above question to answer this one.

I'm a really stupid person and I tried to take the rights of this game and erase Jeff Verkoeyen's name from the programming by putting my name in at the top...but then the calculator laughed at me, screwed up my archive, and erased my RAM...what happened?
	Ok, if you're asking this question, I only have one thing to say to you...DON'T MESS WITH MY STUFF, CUZ THAT'S WHAT YOU GET WHEN YOU TRY AND STEAL OTHER PEOPLE'S WORK!! HAHAHAHAHA

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more