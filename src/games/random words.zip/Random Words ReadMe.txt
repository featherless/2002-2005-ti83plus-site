Random Words v1.1 By Josh Kasten Email: josh6818@hotmail.com,josh697@hotmail.com   AIM screenname: Josh222111

--------------------
3-26-02 at 10:08 PM
The program doesn't excatly make random words it makes random letters.
But you can put how long you want the words to be and how maney.
It stores the words into the string 1 and stores how long the words and how maney into listR.