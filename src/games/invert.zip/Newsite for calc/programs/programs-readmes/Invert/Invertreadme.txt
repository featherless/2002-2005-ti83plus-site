Invert
Original concept- Jeff Verkoeyen
Date made- February, 2002
Features-
	Will work smoothly with any program, just make sure you follow the directions: A=Ymin B=Ymax C=Xmin D=Xmax �=123 (� is the O with the line in the middle) then you need to run the program and it will invert that box that you laid out with the A,B,C,D.
	You can also incorporate this program into a program that you might be making, to invert buttons or text, and best of all, it only inverts the area you specified.  Just store the Y and X values to A,B,C,D and then store 123 to � and then run prgmINVERT and it will invert for you.

FAQ-
When I try and run the program from a program I made, it just shows me the readme part of the program and doesn't invert my graph...what's the matter?
	Make sure that you stored 123 to the O with the line in the middle.
When I run the program, I store 123 to O, but then it shades a weird part of the graph, and I don't feel like writing down all the decimals for all the pixels...is there an easier way?
	Yes actually, there is:  First you need to go to your Window settings, and then store 0 to Xmin, 94 to Xmax, 0 to Ymin, and 62 to Ymax, and this will make the perfect grid, with no decimals (it took me a while to do that, I had to count out all the pixels, lol)

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more