Poker
Original concept- Jeff Verkoeyen
Date made- January, 2002
Features-
	This is kindof a fun little poker game, pretty much completely graphic/getkey based.
	Make sure that you have pic 6&7 on your calc so no errors pop up...

FAQ-
Umm...the game isn't exactly finished....why?
	Well, just to let you know, sometimes I start working on a game or program, but then I never tend to finish it off....the only programs I ever usually completely finish are the Math and other miscellaneous programs.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more