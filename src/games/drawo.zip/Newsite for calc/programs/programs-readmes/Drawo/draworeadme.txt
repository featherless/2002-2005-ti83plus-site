Drawo
Original concept- Jeff Verkoeyen
Date made- September, 2002
Features-
	Drawo is a very usefull program, but it takes up quite a bit of space, therefor limiting some of the things about it.  Also, when you run the program, it flips the picture on it's side, so, if you want to see the picture on it's side, just run this program and wait until it's finished.

FAQ-
I ran the program, and then I waited and waited, but nothing happened, is my calculator frozen?
	No, your calculator isn't frozen, it's just kindof a slow program and it has to store every pixel...
I ran the program, waited a while, and then it said Error:Memory....huh?
	This is a dreadful error, and there are 2 ways to fix it....
		1) Archive all of your programs minus this one, or
		2) Make sure that your entire graph isn't black, because every pixel that is on takes up another 20-50 or so bytes...

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more