Roidian
Original concept- Jeff Verkoeyen
Date made- March, 2002
Features-
	I got the name kindof cleverly actually, first, I wanted to call it Asteroid warz, but that sounded stupid, so I just ripped the Aste part of Asteroid off, and then added -ian to the end, and ~poof!~, out came Roidian!

FAQ-
Umm, yet another unfinished program....c'mon Jeff, get your act together!
	Yes, I know, I will work on all of my unfinished programs once I finish, or start and then never finish some other programs...the only way I'll be able to work on these games anymore is if I'm in the mood for it, or if someone else would like to take the project over (with my written permission of course)

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more