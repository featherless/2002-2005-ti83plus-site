Epic
Original concept- Jeff Verkoeyen and Kris Verwimp
Date made- January, 2002
Features-
	Completely text-based game.
	Story line isn't quite finished, and it seems that Kris isn't writing any more of the script for me, so I've discontinued making it.

FAQ-
The game comes up with errors right when I load it up....why?
	First of all, you need to make sure that you have run the setup program that goes with Epic, and it's not some other setup program for another game.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more