Catch It v0.83 By Josh Kasten 	Email: josh6818@hotmail.com,josh697@hotmail.com   AIM screenname: Josh222111


1. About The Game
2. Install
3. Versions
4. How to play
5. Up Coming Updates
6. HELP!!! If you know ASM HELP



1. About The Game
=======================

Catch it is a very simple game just the catch a falling o.
You must catch 5 falling o's to go to the next level and the higher the level the faster the o's drop and the more points the o's are worth.
And there are end of level bonuses.
----------------------------------------------

2. Install
=======================

Put the following files on your calc:
CATCH IT v0.83.8XP	(the name game)
CATCHSET.8XP		(the setup program note: only run if you want to clear all scores or Catch It won't work)
(opoinal file)LH.8XL	(This is the saved high score in pic on the site.  The scores were generated from me(Josh Kasten) playing Catch It)


3. Versions
========================

3-26-02 at 7:20 PM	      Catch It v0.83
---------------------------------------------

The main reason I released verison 0.83 was bescause of a small syntax error in Catch It v0.82. (I should have test it more o well).
It would happen if you got a high score on easy and it would stop the game so you would have to quit.
The error was a missing " before EASY:
In Catch It v0.83 the error has been fixed and the game is now 4 btyes small. (WOW thats alot jk)
Don't for get to e-mail me about anything that I should change in the game.

Technical Info:
Program size on calc: 2,207 Btyes
Program size on PC:   2,267 Btyes
Program uses the following variables: same as version 0.82
Zip's File size:    6.57KB
unZiped size:       10.50KB
ReadMe's files size:5.67KB



3-25-02 at 8:10 PM		Catch It v0.82
----------------------------------------------

The only thing the I really added to the game was the vary much need super fast right and left buttons.
They are X,T,0,n button and STAT.
I tried to make the code a litle small but I wrought the games so well that I couldn't find many ways to make it smaller.
How ever I did make to a little smaller.
Tell me if any of the str1-str4 is being used by another program you have bascause catch uses these files to save space.
str1-str4 are just temp files for catch It so if you delete them nothing will happen.
I'm still going to add the things I say I was going to in v0.9.
If you want to help me in the project,or,send an idea you have on the game,or,comment on the game,or if you can teach me ASM then e-mail at josh6818@hotmail.com,or, josh697@hotmail.com or IM me at AIM screenname: Josh222111.

Technical Info:
Program size on calc: 2,211 Btyes
Program size on PC:   2,271 Btyes
Note:If you use the quit option when quiting it well cleanup all of the variables below expeded ListH.
Program uses the following variables:A,B,C,E,F,G,H,I,J,K,L,M,N,O,P,Y,Str1,Str2,Str3,str4,ListH
Zip's File size:    6.24KB
unZiped size:       9.62KB
ReadMe's files size:4.69KB



3-19-02  at 1:00 AM		Catch It v0.8
----------------------------------------------
In this new verison of Catch It has way more stuff to it then the the last one.
heres whats new:
3 difficulty levels you can pick
The game now has a scoring system with many formulas and high scores
There is a life meater in Catch It and when it gets to 0 you lose

Technical Info:
Program size on calc: 2,216 Btyes
Program size on PC:   2,276 Btyes
Program uses the following variables:A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Y,Str1,Str2,Str3,ListH
Zip's File size:    5.68KB
unZiped size:       7.66KB
ReadMe's files size:3.18KB



3-16-02	at 12:11 PM		Catch It v0.7
----------------------------------------------
Catch it is a very simple game just the catch a falling o.
You must catch 5 falling o's to go to the next level and the higher the level the faster the o's drop.
I will be working on adding more to the game vary soon.

Technical Info:
Program size on calc: 628 Btyes
Program size on PC:   688 Btyes
Program uses the following variables:A,B,C,D,E,F,G,H,M,Y,Str1
Zip's File size:    1.85KB
unZiped size:       2.75KB
ReadMe's files size:1.66KB
-----------------------------------------------



4. How To play
========================

Just catch the falling o's
-----------------------------------------------
KEYS:
-----------------------------------------------
X,T,0,n Button:Moves left super fast
STAT:	       Moves right supper fast
MODE:	       Moves left fast
DEL:           Moves right fast
Left Arrow:    Moves left
Right Arrow:   Moves right
-----------------------------------------------



5. Up Coming Updates
========================

Verion 0.9 will most likly have the fowing updates
They are:
------------------------------------------------
1. Power ups
2. Money so you can buy the power ups
3. Possably some kind of change to the scoring system
4. Send me some ideas to josh697@hotmail.com and i might add it if it sounds good
5. Clean up my program so its small and faster
------------------------------------------------


Verion .8 is going to have a whole ton of up dates.
They Are:
------------------------------------------------
1. A scoring system with the top 5 high scores with an inputed name.
2. 3 difficulty levels
3. A possible way to die
4. And manybe a 4th add on
------------------------------------------------


6. HELP!!! If you know ASM HELP
========================

HELP If you know ASM for the TI 83+ please could you spare some time to teach how to program in ASM.
I know some like ld a,0  this loads 0 in a.
and jr jumps to a leable 128 bytes a way from jr.


Catch It v0.83 By Josh Kasten 	Email: josh6818@hotmail.com,josh697@hotmail.com   AIM screenname: Josh222111