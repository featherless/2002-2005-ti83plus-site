PixWorks
Original concept- Jeff Verkoeyen
Date made- March, 2002
Features-
	This is a great program for anyone out there who loves to draw, you can do many different shapes, shade, shadely invert, invert, and use a pen that is much faster than the traditional pen.


�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more