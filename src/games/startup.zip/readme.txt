�2002 Jeff Verkoeyen
programs/games shown here by-  Ian Olsen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more