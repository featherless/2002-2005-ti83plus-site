Arcade
Original concept- Jeff Verkoeyen
Shoot, Hover Pong, Find Me, Guess, TacTicToe, and Rapid NAMES by Jeff Verkoeyen
Targetra 1&2, Sequence, and Stop NAMES by Josh Rodasti
All games programmed by Jeff Verkoeyen
Date made- March, 2002
Date updated- May, 2002
Date updated again- November, 2002
Features-
	This Arcade probably is one of the best things you can find out there to spend your time playing, because there are so many things to do.  Almost every game keeps track of its own high scores, and there is also an overall high score for the entire Arcade.
	Shoot-
	This is a fun game, it's pretty hard though, so it might take some mastering to get used to.
	Hover Pong-
	I don't know why, but for some reason everyone thinks this game is slow, well, I'll give you one hint as to why it is THIS GAME IS IN BASIC, and if you think about it, it's actually pretty fast for being a basic game (and it's small too).
	Targetra 1&2-
	These games are fun, and they help you work on your timing.
	Sequence-
	Ever played Simon? well, this is pretty much just like it, but no colors.  Just press the button it tells you to.
	Stop-
	This is another timing game, you've got to stop the ball right underneath the line, and it can get going pretty fast on some of the higher levels.
	Rapid-
	This has got to be the best game I've made that isn't an RPG.  This was originally actually meant to be the battle system for my RFRPG game, but then it kindof slowly evolved itself into a game all in itself.  with a hidden game play mode after beating level 255, this game is truly one of the best you could find.  (I haven't beaten level 255 yet, so I'm hoping it works...lol)
	Tactictoe-
	You can probably figure this out
	Guess-
	This is another game of mine you'll probably recognize from ticalc.org, but there it is known as The Ultimate Guess!
	Find Me-
	You might recognize this if you've played a lot of games.  This game is based on the game where you have three cups, you place a ball underneath one of them, and then you start shifting them around.  When they stop, you have to find the ball.


	FAQ and FAQATC (Frequently Asked Questions About The Commands)

	first of all, in almost every one of the games, you can press Alpha to turn the calc off, Mode to quit (except for Hover Pong, you press 2nd in there to quit), and 2nd is usually confirm and sometimes Enter needs to be used also.
	second, the commands-


	Tactictoe is probably the first one I need to explain, and I'll draw it out for you-

	here is the calculator buttons-

	7 8 9
	4 5 6
	1 2 3

	and here is the Tactictoe screen it'll show-

	I-I-I-I Player 1
	I I I I
	I-I-I-I
	I I I I
	I-I-I-I
	I I I I
	I-I-I-I

	see any similarities?  when you press 7, the top left square will fill up, and when you press 5, the middle square will fill up.  You can't win any points in this game towards your overall score, but it's fun when you have someone else to play it with.


	The second game that seems to be most controversial is my Hover Pong game-

	here are the commands used-

	Mode- Move left fast
	Del-  Move right fast
	arrows- You almost never need these keys, because they're too slow, but they'll help your accuracy a bit
	alpha and mode- look above^^^

	What I don't get is why nobody can comprehend the fact that you just press Mode to move to the left, and Del to move to the right.  The people I had to try out the game all kept going, doidoidee, I'll just press Del and get mad because I'm not moving to the left, but instead am going to the right, doideedoi!
	Another thing to note, is that the Mode button doesn't "regenerate itself" as I like to say it, because when you press the Mode key, if you hold it down, you're only going to move once, and then you're gonna stop, and probably be frustrated and wonder why it didn't work.  Del and the arrow keys are the only keys that "regenerate themselves".


	Ok, now the third game that needs a lot of explaining is Guess, not just for the commands, but for the overall gameplay-

	In Guess, there are two modes, one player, and two player
	One player mode is pretty self explanatory, but it's two player mode that needs to be explained-

	To play 2 player mode, and have it work, you must follow these directions, and I'll show you what each calc screen should look like throughout the game-

	Step one!
	LOAD UP THE GAME, DUH
	Step two
	both calculators should say this

		Calc 1				Calc 2
	     GUESS			     GUESS
	1:START				1:START
	2:HELPER OFF (or on)		2:HELPER OFF
	3:SETUP				3:SETUP
	4:QUIT				4:QUIT

	Now you both need to select start by pressing one or just hitting enter or however you please, and then your screens should look like this-

		Calc 1				Calc 2
	     GUESS			     GUESS
	1:1 PLAYER			1:1 PLAYER
	2:2 PLAYER			2:2 PLAYER
	3:BACK				3:BACK

	Now you both need to click 2 player by pressing 2 or just moving it down to it...then your calcs should look like this-

		Calc 1				Calc 2
	MAKE SURE THE LINK		MAKE SURE THE LINK
	IS CONNECTED			IS CONNECTED

	and then you just both press enter-

		Calc 1				Calc 2
	    PLAYER			    PLAYER
	1:PLAYER 1			1:PLAYER 1
	2:PLAYER 2			2:PLAYER 2
	3:BACK				3:BACK

	now here's the parting of ways, I'll assume calc 1 is going to be player 1, and calc 2 is going to be player 2, so they'll just click those-

		Calc 1				Calc 2
	PRESS ENTER WHEN		PRESS ENTER
	YOU ARE READY			AFTER PLAYER
	PLAYER ONE			ONE'S CALC SAYS
					LINKED!

	Now player one has to press enter, while player 2 just hangs tight....

		Calc 1				Calc 2
	LINKED!				PRESS ENTER
					AFTER PLAYER
					ONE'S CALC SAYS
					LINKED!

	Now that player one's calc says linked, (if it says error, then check the cable and start again from the top) player 2 can press enter-

		Calc 1				Calc 2
	LINKED!				LINKED!
					PLAYER 1 IS
					SETTING THE GAME
					UP

	Now player one should press enter and the screen's will look like this-

		Calc 1				Calc 2
	BETWEEN 1 AND ?-		LINKED!
	(type whatever you want here	PLAYER 1 IS
	 for the limit)			SETTING THE GAME
					UP

	and then player one sets up what the limit is for the game and presses enter, then player two should press enter and both of your screens will look like this hopefully-

		Calc 1				Calc 2
	READY?				READY?

	now you both press enter and guess away!

	REGARDING THE IN-GAME SHOP AND BUYING GAMES!!
	If you are wondering why you can't play some of the games, it's because you have to buy the game's from the shop using your points...If I were you, I'd buy the most expensive games first, because they're the funnest ones, like Rapid and Guess.

	hopefully this will answer all of anyone's questions....but if you have another one, just email me and I'll write back as soon as I can


�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more