TRI By Josh Kasten Email: josh6818@hotmail.com,josh697@hotmail.com   AIM screenname: Josh222111

--------------------
MY first and olny release of tri.
The program draws trianges randomly that that up most of the screen i guess you could call it a screen saver.