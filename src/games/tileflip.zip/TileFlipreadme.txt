Tile Flip
Original concept- Jeff Verkoeyen
Date made- November, 2001
Features-
	TileFlip is a remake of the game BeJeweled.  I saw this game on a palm pilot and
	decided to try and remake it.  It may not be as fast, but it's still good.
	2nd  selects a tile
	Alpha turns the power off
	XTOn GarbageCollects
	Mode Quits
	Stat Shows stats
	Y= Search Quality
	Window Pause

FAQ-
	When I press Alpha, it says archived?
		Make sure that all of these files are UNARCHIVED:
		Shutdown
		Tileflip
		Tileflia
		Invertxt

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more