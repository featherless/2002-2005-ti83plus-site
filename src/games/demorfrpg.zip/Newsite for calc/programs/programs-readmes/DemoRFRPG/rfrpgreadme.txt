Demo of RFRPG
Original concept- Jeff Verkoeyen
Date made- March, 2002
Features-
	This is a game/demo of RFRPG and it has up to 248 levels, I haven't been able to beat level 248 yet, so if you do beat it, send me an email, so I can post your name on my site, because that deserves congratulating.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more