HitShot
Original concept- Jeff Verkoeyen
Date made(original)- September, 2001
Date made(ported into Raging Flame 2)- February, 2002
Features-
	Hitshot is a pretty fun game where you have a certain time limit, a certain number of lives, and a high score that you need to beat.
	In the ported version, you can actually win money from beating the record, and the overall game is a little faster to play (no explosion when you hit the target)

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more