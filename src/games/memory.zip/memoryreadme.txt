Memory
Original concept- Jeff Verkoeyen
Date made- November, 2002
Features-
	This is a fun game, based on the old-style, flip the card and remember where it is, game.
	Has save features, and also power-off, and stats.
KeyPresses:
	2nd selects a tile
	Mode quits
	Alpha turns the power off
	XTOn does a garbagecollect (in case it starts getting slow)
	Del Saves
	Arrow keys move the cursor
	Stat shows your stats

FAQ-
I pressed Alpha while in the game, and it said, ERR:ARCHIVED...what's that mean?
	Make sure that the program SHUTDOWN is UNARCHIVED, or else the program will not work
	when you try and turn the power off.
I tried to load my game, but it said ERR:UNDEFINED....help!
	You probably haven't saved a game yet, so you'll need to go back in, start a new game,
	and press Del to save in it, it will say SAVED, if it was accomplished succesfully.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more