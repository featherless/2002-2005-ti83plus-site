Rapid-Fire Role-Playing Game Promotional
Original concept- Jeff Verkoeyen
Date made- March, 2002
Features-
	This is a promotional for my future line-up of RPG's...
	Getting sick of the old-fashioned, sit, move cursor to attack, wait to be hit, restart sequence and move cursor again, games?  Well, here's your remedy, with RFRPG's, you'll be able to give not only your brain a work-out with the puzzles, but also your fingers as you tap away at the keys trying to kill the enemy!

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more