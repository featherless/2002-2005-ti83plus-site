Seven Stones
Original concept- Jeff Verkoeyen
Date made- December, 2001
Features-
	This is a game which I based on a book (one of the Fighting Fantasies, if you've ever heard of them) and I never really could figure out a good enough story-line to continue working on it, but you can try it out and tell me what you think of it.

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more