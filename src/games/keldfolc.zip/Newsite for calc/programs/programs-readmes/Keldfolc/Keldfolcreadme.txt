Keldfolc
Original concept- Jeff Verkoeyen
Date made- April, 2001
Features-
	Keldfolc is one of my very first RPG's I've made, and I'm still quite proud that I knew how to make a game like this within 2 months of getting my calculator, even though it does take up quite a bit of space.

FAQ-
So, I start off, but then I don't know what to do....?
	Well, there are quite a few things to do, first you can fight monsters (I would start with the first monster and work your way up, because the Gold Man is really hard to beat when you are at level one), also, you can go to the nearest town and buy health/attack/defense to help you out a bit (I like saving up for the nunchucks, they give you the biggest boost in attack)

�2002 Jeff Verkoeyen
any more questions, email Jeff at-
ragingflame@msn.com
or visit the sites at-
http://ragingflame.150m.com
http://www21.brinkster.com/jverkoey/ragingflame/
http://www21.brinkster.com/jverkoey/ragingflame/newproject/
http://www21.brinkster.com/jverkoey/tiproject/

ragingflame.150m.com branches off to all three of the www21... sites and more